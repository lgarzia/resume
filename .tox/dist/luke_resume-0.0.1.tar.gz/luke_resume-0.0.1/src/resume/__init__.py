""" Luke Garzia's Resume CLI App - Making Resumes fun since 2022 """
__version__ = "0.0.1"
